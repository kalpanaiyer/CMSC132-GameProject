
package game;

/*
CLASS: SpaceGame
DESCRIPTION: Extending Game, SpaceGame is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.

*/
import java.awt.*;
import java.awt.event.*;
import java.util.TimerTask;

import javax.management.timer.Timer;

/**
 * This class extends Game and represents the logic of a SpaceGame Keeper. The
 * elements can be updated either by movement or game status.
 * 
 * @author Rissah Remy and Kalpana Iyer
 */
class SpaceGame extends Game {
	static int counter = 0;
	Point[] shipPoints = {
			// x y
			new Point(0, 25), // bL
			new Point(0, 0), // tL
			new Point(50, 0), // tR
			new Point(50, 25), // bR
			new Point(0, 25), // bL
			new Point(-50, 100), new Point(100, 100), new Point(50, 25) };

	Point[] shipBigWindowPoints = {
			// x y
			new Point(0, 20), // bL
			new Point(0, 0), // tL
			new Point(40, 0), // tR
			new Point(40, 20), // bR
			new Point(0, 20) };

	Point[] shipSmallWindowPoints2 = {
			// x y
			new Point(0, 10), // bL
			new Point(0, 0), // tL
			new Point(10, 0), // tR
			new Point(10, 10), // bR
			new Point(0, 10) };

	Point[] enemyPoints = {
			// x y
			new Point(0, 50), // bL
			new Point(25, 25), // mL
			new Point(0, 0), // tL
			new Point(35, 10), // tM
			new Point(75, 0), // tR
			new Point(50, 25), // mR
			new Point(75, 50), // bR
			new Point(35, 40), // bM
	};

	Point[] laserz = { new Point(0, 50), // bL
			new Point(0, 0), // tL
			new Point(50, 0), // tR
			new Point(50, 50), // bR
	};

	Point[] powerUp = { new Point(0, 0), new Point(25, 25), new Point(50, 0), };

	private SpaceShip ship = new SpaceShip(shipPoints, new Point(500, 500), 0);
	private Enemies enemy = new Enemies(enemyPoints, new Point(200, 200), 0);
	private GameState state;
	private PowerUp p = new PowerUp(laserz, new Point(500, 500), 0);
	private ScoreUp s = new ScoreUp(powerUp, new Point(200, 200), 0);

	/**
	 * Initializes a SpaceGame. Relies on the super class constructor to create the
	 * game's frame. Starts the game when called.
	 */
	public SpaceGame() {
		super("SpaceGame!", 800, 600);
		this.setFocusable(true);
		this.requestFocus();
		this.addKeyListener(ship);
		state = GameState.PLAYING;

	}

	/**
	 * Inner Class PowerUp extends Polygon. We define methods that track when to
	 * reappear a power up.
	 */
	class PowerUp extends Polygon {
		boolean check;

		/**
		 * Initializes a PowerUp Objects shape, position and rotation. Relies on the
		 * super class constructor to define the shape.
		 * 
		 * @param inShape    contains array of points of the polygon object
		 * @param inPosition offsets for the polygon, allows movement of object
		 * @param inRotation rotates shape a direction based on degrees
		 */
		public PowerUp(Point[] inShape, Point inPosition, double inRotation) {
			super(inShape, inPosition, inRotation);
			check = false;
		}

		/**
		 * Accesses Point array to assign points coordinates to create the power up's
		 * frame. Uses brush passed as a parameter to create the power up's next frame.
		 * 
		 * @param brush draws current element
		 */
		public void paint(Graphics brush) {
			Point[] points = this.getPoints();
			int[] xpoints = new int[points.length];
			int[] ypoints = new int[points.length];
			int xInc = 0, yInc = 0;

			for (Point p : points) {
				xpoints[xInc++] = (int) p.getX();
			}

			for (Point p : points) {
				ypoints[yInc++] = (int) p.getY();
			}

			brush.drawPolygon(xpoints, ypoints, xInc);
			brush.fillPolygon(xpoints, ypoints, xInc);
		}

		/**
		 * Uses gameCounter passed as a parameter to check if. Returns a boolean of true
		 * if the game counter are increments of 200, (e.g 200, 400, 600) and returns
		 * false otherwise.
		 * 
		 * @param gameCounter has the current time of the game
		 * @return check if divisible by 200
		 */
		boolean appearTime(int gameCounter) {
			if (gameCounter % 200 == 0) {
				check = true;
			}

			return check;
		}

		/**
		 * Returns a boolean of Game's current state or next move.
		 * 
		 * @return check current value
		 */
		boolean getCheck() {
			return check;
		}

		/**
		 * Uses <code>check</code> to cue the game to appear a new power up. Checks that
		 * the old power up is gone and is true. Power up appears if true and power up
		 * is gone, otherwise doesn't.
		 * 
		 * @param p reference of ScoreUp object
		 * @param s reference of SpaceShip object
		 */
		void applyPowerUp(PowerUp p) {
			if (check == true && p.collides(ship)) {
				ship.increaseStepSize(5);
				check = false;
			}

		}

	}

	/**
	 * Modifies the visual of the frame's texts. Controls SpaceShips movement.
	 * Contains a lambda expression to check Game's current condition. Calls
	 * shouldEndCon method to check if the counter has reached the maximum, if so,
	 * then the game should be over, and a message will be printed.
	 * 
	 * @param brush draws current visuals
	 */
	public void paint(Graphics brush) {
		brush.setColor(Color.black);
		brush.fillRect(0, 0, width, height);

		// sample code for printing message for debugging
		// counter is incremented and this message printed
		// each time the canvas is repainted
		counter++;

		brush.setColor(Color.gray);
		brush.drawString("Counter is " + counter, 10, 10);

		if (state == GameState.PLAYING) {
			brush.drawString("Welcome to SpaceGame! Get as many points as you can" + " before the counter hits 2000!",
					10, 30);

			ship.move();

			brush.setColor(Color.gray);
			ship.paint(brush);

			// paints enemy
			brush.setColor(Color.yellow);
			enemy.paint(brush);

			if (p.appearTime(counter) == true) {
				brush.setColor(Color.blue);
				p.paint(brush);
				p.applyPowerUp(p);
				brush.setColor(Color.white);
				brush.drawString("Speed Powerup Activated!", 10, 90);
			}

			if (s.appearTime(counter) == true) {
				brush.setColor(Color.blue);
				s.paint(brush);
				brush.setColor(Color.white);
				brush.drawString("Extra Points Powerup Activated!", 10, 70);
				s.applyPowerUp(s, ship);
			}

			ship.checkCollisionsWithEnemy(enemy);
			ship.wrapAround(width, height);
			ship.reachedEdge(width, height);

			brush.setColor(Color.green);
			brush.drawString("Score: " + ship.getScore().getPoints(), 10, 50);

		}

		GameEndCondition endCon = (counter) -> counter >= 2000;

		if (endCon.shouldEndGame(counter)) {
			state = GameState.GAME_OVER;
		}

		if (state == GameState.GAME_OVER) {
			brush.drawString("GAME OVER! You Win! Your Score Is: " + 
		ship.getScore().getPoints(), 10, 30);
		}
	}

	/**
	 * Instantiates the SpaceGame object and redraws it continously.
	 * 
	 * @param args retrieve input from console
	 */
	public static void main(String[] args) {
		SpaceGame s = new SpaceGame();
		s.repaint();
	}
}