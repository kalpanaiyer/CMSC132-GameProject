package game;

/**
 * Defines the functional interface of the GameEndConditon.
 * 
 * @author Rissah Remy and Kalpana Iyer
 */
public interface GameEndCondition {
	/**
	 * Ends the game based on the parameter's counter information. If the current
	 * counter is greater than or equal to 2000, then the game should end.
	 * 
	 * @ param counter tracks the timer
	 */
	boolean shouldEndGame(int counter);

}
