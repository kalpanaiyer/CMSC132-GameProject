package game;

/**
 * This enumerated type represents the game current state. A game is either
 * still playing (e.g. PLAYING) or is done (e.g. GAME_OVER).
 * 
 * @author Rissah Remy and Kalpana Iyer
 */
public enum GameState {
	PLAYING, GAME_OVER;
}
