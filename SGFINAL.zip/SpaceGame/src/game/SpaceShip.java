package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*;
import java.util.TimerTask;

/**
 * This class extends Polygon. It implements the KeyListener interface. We
 * define methods that track the movement of a SpaceShip and its edges.
 * 
 * @author Rissah Remy and Kalpana Iyer
 */
public class SpaceShip extends Polygon implements KeyListener {
	private double stepSize = 5.0, x, y;
	private Point inPosition;
	private Score score;
	private boolean leftPress, rightPress, forwardPress, check;

	/**
	 * Initializes a SpaceShip shape, position and rotation. Relies on the super
	 * class constructor to define the shape. Uses <code>x</code> and <code>y</code>
	 * to have the current position.
	 * 
	 * @param inShape    contains array of points of the polygon object
	 * @param inPosition offesets for the polygon, allows movement of object
	 * @param inRotation rotates shape a direction based on degrees
	 */
	public SpaceShip(Point[] inShape, Point inPosition, double inRotation) {
		super(inShape, inPosition, inRotation);
		this.inPosition = inPosition;
		score = new Score();
		x = inPosition.getX();
		y = inPosition.getY();
	}

	/**
	 * Accesses Point array to assign points coordinates to create the spaceship's
	 * frame. Uses brush passed as a parameter to create the spaceship's next frame.
	 * Print's Enemy's message when it reappears.
	 * 
	 * @param brush draws current element
	 */
	public void paint(Graphics brush) {
		Point[] points = this.getPoints();
		int[] xpoints = new int[points.length];
		int[] ypoints = new int[points.length];
		int xInc = 0, yInc = 0;

		for (Point p : points) {
			xpoints[xInc++] = (int) p.getX();
		}

		for (Point p : points) {
			ypoints[yInc++] = (int) p.getY();
		}

		brush.drawPolygon(xpoints, ypoints, xInc);
		brush.fillPolygon(xpoints, ypoints, yInc);

		if (check == true) {
			brush.setColor(Color.yellow);
			brush.drawString(task.toString(), 10, 120);
		}

	}

	/**
	 * Instantiates a TimerTask Anonymous Class. Uses method to print a message.
	 */
	TimerTask task = new TimerTask() {
		/**
		 * Uses a run method as an inherited abstract method
		 * Overrides the run abstract method
		 */
		@Override
		public void run() {
			System.out.println("");

		}

		/**
		 * Uses a toString method to print a message for the Enemy.
		 * Overrides the toString method.
		 * 
		 * @return a message
		 */
		@Override
		public String toString() {
			return "I've reappeared Hahaha!!";
		}
	};

	/**
	 * Allows the looping around the screen so that a SpaceShip never disappears
	 * forever.
	 */
	public void wrapAround(int screenWidth, int screenHeight) {

		if (x > screenWidth) {
			x = 0; // Wrap to the left side
		} else if (x < 0) {
			x = screenWidth; // Wrap to the right side
		}
		if (y > screenHeight) {
			y = 0; // Wrap to the top
		} else if (y < 0) {
			y = screenHeight; // Wrap to the bottom
		}
	}

	/**
	 * Checks that the element has not reached the edge of the screen.
	 * 
	 * @return either x or y has or has not reached the edge using a boolean
	 */
	public boolean reachedEdge(int screenWidth, int screenHeight) {
		return x > screenWidth || x < 0 || y > screenHeight || y < 0;
	}

	/**
	 * A Score Inner Class. Tracks the score of the Game.
	 */
	class Score {
		private int points;

		/**
		 * Initializes a Score object. Assigns the point to start at a value of zero.
		 */
		public Score() {
			this.points = 0;
		}

		/**
		 * Returns current point progress of the game in relation with colliding with
		 * the elements.
		 * 
		 * @return points current points
		 */
		public int getPoints() {
			return points;
		}

		/**
		 * Increases the current progress of the game's point system.
		 * 
		 * @param amount passes new points needed to be added to the current
		 */
		public void increasePoints(int amount) {
			points += amount;
		}

		/**
		 * Assigns a new score to the current Game's score.
		 * 
		 * @param score passes new points needed to be added to the current
		 */
		public void setScore(int score) {
			points = score;
		}
	}

	/**
	 * Allows enemy's spawn coordinate to move if Spaceship's points collide with
	 * Enemy points. And increase points if a collision has occurred, otherwise
	 * returns false
	 * 
	 * @param enemy references an enemy object
	 * @return check collision has occurred or not
	 */
	public boolean checkCollisionsWithEnemy(Enemies enemy) {
		if (collides(enemy)) {
			score.increasePoints(1);
			enemy.move(); // allows the enemy to continously spawn

			check = true;
		}
		return check;

	}

	/**
	 * Returns current Game's score.
	 * 
	 * @return score current score amount
	 */
	public Score getScore() {
		return score;
	}

	/**
	 * Modifies Spaceships coordinate based on user's keyboard input. LeftPress
	 * moves ship left, RightPress moves ships right, and ForwardPress rotates ship.
	 */
	public void move() {
		inPosition.setX(x);
		inPosition.setY(y);

		if (leftPress == true) {
			rotation -= stepSize;
		}
		if (rightPress == true) {
			rotation += stepSize;
		}

		if (forwardPress == true) {
			x += stepSize * Math.cos(Math.toRadians(rotation));
			y += stepSize * Math.sin(Math.toRadians(rotation));
		}

	}

	/**
	 * Tracks user's keyboard input key code when pressed. Event determines what
	 * movement is allowed. LeftPress moves ship left, RightPress moves ships right,
	 * and ForwardPress rotates ship.
	 */
	@Override
	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();

		if (keyCode == KeyEvent.VK_UP) {
			forwardPress = true;
		} else if (keyCode == KeyEvent.VK_LEFT) {
			leftPress = true;
		} else if (keyCode == KeyEvent.VK_RIGHT) {
			rightPress = true;
		}
	}

	/**
	 * Tracks user's keyboard input key code when released. Event determines what
	 * movement is stopped when user doesn't interact with the keyboard anymore.
	 * LeftPress released moves ship nowhere, RightPress released moves ship
	 * nowhere, and ForwardPress rotates ship nowher.
	 */
	@Override
	public void keyReleased(KeyEvent e) {
		int keyCode = e.getKeyCode();

		if (keyCode == KeyEvent.VK_UP) {
			forwardPress = false;
		} else if (keyCode == KeyEvent.VK_LEFT) {
			leftPress = false;
		} else if (keyCode == KeyEvent.VK_RIGHT) {
			rightPress = false;
		}
	}

	/**
	 * Tracks user's keyboard input key code when a keycode is typed.
	 */
	@Override
	public void keyTyped(KeyEvent e) {
		// left empty
	}

	/**
	 * Increases the distance a SpaceShip can move
	 */
	public void increaseStepSize(int size) {
		stepSize += size;
	}

}
