package game;

import java.awt.Color;
import java.util.*;
import java.awt.Graphics;
import java.awt.*;
import java.awt.event.*;

/**
 * This class extends Polygon and implements the functionality of an enemy. We
 * define a method that randomizes the next position of an enemy.
 * 
 * @author Rissah Remy and Kalpana Iyer
 */
public class Enemies extends Polygon {
	static int counter = 0;
	private Point inPosition;
	private double x, y;

	/**
	 * Initialized Enemy's state, shape, position and rotation. Relies on the super
	 * class constructor to define the shape. Uses <code>x</code> and <code>y</code>
	 * to have the current position.
	 * 
	 * @param inShape    contains array of points of the polygon object
	 * @param inPosition offesets for the polygon, allows movement of object
	 * @param inRotation rotates shape a direction based on degrees
	 */
	public Enemies(Point[] inShape, Point inPosition, double inRotation) {
		super(inShape, inPosition, inRotation);
		this.inPosition = inPosition;
		x = inPosition.getX();
		y = inPosition.getY();
	}

	/**
	 * Accesses Point array to assign points coordinates to create the enemy's
	 * frame. Uses brush passed as a parameter to create the enemy's next frame.
	 * 
	 * @param brush draws current element
	 */
	public void paint(Graphics brush) {
		Point[] pointsArray = this.getPoints();
		int[] xpoints = new int[pointsArray.length];
		int[] ypoints = new int[pointsArray.length];
		int xInc = 0, yInc = 0;

		for (Point p : pointsArray) {
			xpoints[xInc++] = (int) p.getX();
		}

		for (Point p : pointsArray) {
			ypoints[yInc++] = (int) p.getY();
		}

		brush.drawPolygon(xpoints, ypoints, xInc);
		brush.fillPolygon(xpoints, ypoints, yInc);

	}

	/**
	 * Sets the current enemy locations to a randomized coordinate
	 */
	public void move() {
		x = 50 + Math.random() * 500;
		y = 50 + Math.random() * 500;
		inPosition.setX(x);
		inPosition.setY(y);

	}

}
