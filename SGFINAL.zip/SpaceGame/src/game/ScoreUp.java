package game;

import java.awt.Graphics;
import game.SpaceGame.PowerUp;

/**
 * This class extends Polygon and implements the functionality of a Score
 * Keeper. We define a method that tracks when power ups should appear.
 * 
 * @author Rissah Remy and Kalpana Iyer
 */
public class ScoreUp extends Polygon {
	boolean check;

	/**
	 * Initializes a ScoreUp's state, shape, position and rotation. Relies on the
	 * super class constructor to define the shape. Uses <code>check</code> to
	 * control if its time to use a power up or not.
	 * 
	 * @param inShape    contains array of points of the polygon object
	 * @param inPosition offesets for the polygon, allows movement of object
	 * @param inRotation rotates shape a direction based on degrees
	 */
	public ScoreUp(Point[] inShape, Point inPosition, double inRotation) {
		super(inShape, inPosition, inRotation);
		check = false;
	}

	/**
	 * Accesses Point array to assign points coordinates to create the power up's
	 * frame. Uses brush passed as a parameter to create the power up's next frame.
	 * 
	 * @param brush draws current element
	 */
	public void paint(Graphics brush) {
		Point[] points = this.getPoints();
		int[] xpoints = new int[points.length];
		int[] ypoints = new int[points.length];
		int xInc = 0, yInc = 0;

		for (Point p : points) {
			xpoints[xInc++] = (int) p.getX();
		}

		for (Point p : points) {
			ypoints[yInc++] = (int) p.getY();
		}

		brush.drawPolygon(xpoints, ypoints, xInc);
		brush.fillPolygon(xpoints, ypoints, xInc);
	}

	/**
	 * Uses gameCounter passed as a parameter to check if. Returns a boolean of true
	 * if the game counter are increments of 200, (e.g 200, 400, 600) and returns
	 * false otherwise.
	 * 
	 * @param gameCounter has the current time of the game
	 * @return check if divisible by 200
	 */
	boolean appearTime(int gameCounter) {
		if (gameCounter % 200 == 0) {
			check = true;
		}

		return check;
	}

	/**
	 * Uses <code>check</code> to cue the game to appear a new power up. Checks that
	 * the old power up is gone and is true. Power up appears if true and power up
	 * is gone, otherwise doesn't.
	 * 
	 * @param p reference of ScoreUp object
	 * @param s reference of SpaceShip object
	 */
	void applyPowerUp(ScoreUp p, SpaceShip s) {
		if (check == true && p.collides(s)) {
			s.getScore().increasePoints(2);
			check = false;
		}

	}
}
